package com.coding.vowels;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import java.io.FileNotFoundException;

/*
Author - Amit Singh Baghel
This is main spring boot application from where processing starts.
 */
@Slf4j
@SpringBootApplication
@ComponentScan(basePackages = "com.coding.vowels.")
public class VowelsApplication {
    public static void main(String[] args) throws FileNotFoundException {
        ApplicationContext applicationContext = SpringApplication.run(VowelsApplication.class, args);
        ProcessingVowels processingVowels = applicationContext.getBean(ProcessingVowels.class);
        processingVowels.process();
    }

}
