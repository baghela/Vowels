package com.coding.vowels;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
/*
This Interface will combine all processes required for the task. Reading from file , Processing it an dwriting back
 */

@Component
@Service
public interface ProcessingVowels {
    void process() throws FileNotFoundException;

}
