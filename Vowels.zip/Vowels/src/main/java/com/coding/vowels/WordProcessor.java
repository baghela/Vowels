package com.coding.vowels;

import org.springframework.stereotype.Service;

/*
Author- Amit Singh Baghel
This interface is written process the words . This will return vowels , average and length of word.
 */
@Service
public interface WordProcessor {

     String processWord(String word);
}
