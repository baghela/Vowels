package com.coding.vowels;

/*
Author- Amit Singh Baghel
This interface is written to read the content from file and write it back after processing
 */

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;

@Service
@Component
public interface FilesReaderWriter {

     String readFromFile(String fileName) throws FileNotFoundException;
     void writeToFile(String fileName,String content) throws FileNotFoundException;
}
