package com.coding.vowels.impl;

import com.coding.vowels.WordProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

/*
Author- Amit Singh Baghel
This class is  implementing word processor .This will take care of all processing required in problem statement.
 This will return vowels , average vowels per word and length of word.
 */
@Slf4j
@Component
public class WordProcessorImpl implements WordProcessor {
   final List<Character> vowels = new ArrayList<>(Arrays.asList('a', 'e', 'i', 'o', 'u'));

    @Override
    public String processWord(String input) {
        //This method is backbone or program.All desired result are calculated here.
        log.info("Inside ProcessWord method with Input parameter"+input);
        StringBuilder processedOutput = new StringBuilder();
        String[] wordsArray = input.trim().replaceAll("\\p{Punct}", "").split("\\s+",0);
        List<String> words = Arrays.asList(wordsArray);
        words.forEach(word -> {
                    long vowelCount = word.chars().mapToObj(i -> (char)i).filter(vowels::contains).count();
                    long length = word.length();
                    double average = vowelCount!=0?Double.valueOf(length)/Double.valueOf(vowelCount):0.0;
                    String vowels = getVowels(word);
                    processedOutput.append("(({");
                    processedOutput.append(vowels);
                    processedOutput.append("}) ,");
                    processedOutput.append(length);
                    processedOutput.append(") -> ");
                    processedOutput.append(average);
                    processedOutput.append("\n");
        }
        );
        log.info("Exiting  ProcessWord method with Return variable  "+processedOutput.toString());
        return processedOutput.toString();
    }

    public String getVowels(String word) {
        //This method will give unique vowels present in the String
        log.info("Inside getVowels method with parameter " +word);
        StringBuilder vowelSb = new StringBuilder();
        Set<Character> vowelsSet = new HashSet<>();
        for (int i = 0; i < word.length(); i++) {
            if (vowels.contains(word.charAt(i))) {
                if (vowelsSet.add(word.charAt(i))) {
                    vowelSb.append(word.charAt(i));
                    vowelSb.append(',');
                }
            }
        }
        log.info("Exiting  getVowels method with return variable " +vowelSb);
        return vowelSb.length()!=0?vowelSb.substring(0, vowelSb.toString().length()-1):null;
    }
}
