package com.coding.vowels.impl;

import com.coding.vowels.FilesReaderWriter;

import java.io.*;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


/*
Author- Amit Singh Baghel
This class is  implementing FilesReaderWriter .This will read the file input.txt and load into String.
Once processing is done it will write back the file with desired output.txt
 */
@Component
@Slf4j
public class FilesReaderWriterImpl implements FilesReaderWriter {

    @Override
    public String readFromFile(String fileName) throws FileNotFoundException {
        //This method will read from file input.txt and load data into a string
        log.info("Inside readFromFile method . File name received is {}", fileName);
        byte[] buffer = new byte[10];
        StringBuilder sbInput = new StringBuilder();
        try (FileInputStream fileInput= new FileInputStream(fileName)){

            while (fileInput.read(buffer) != -1) {
                sbInput.append(new String(buffer));
                buffer = new byte[10];
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            log.error("Exception while reading from file "+ex.getMessage() );
            throw new FileNotFoundException();
        }
        log.info("ReadFromFile processed successfully . Content of file is {}" + sbInput.toString());
        return sbInput.toString();
    }

    @Override
    public void writeToFile(String fileName,String content) throws FileNotFoundException {
        //This method will write the processed output to file.
        log.info("Inside method writeToFile. File name is " + fileName + "Content to be written in file is " + content);
        File path = new File(fileName);
        FileWriter wr = null;
        try {
            wr = new FileWriter(path);
            wr.write(content);
            wr.flush();
            wr.close();
            log.info("Write to file completed successfully");
        } catch (IOException ex) {
            ex.printStackTrace();
            log.error("Exception while writing to file " + ex.getMessage());
            throw new FileNotFoundException();
        }

    }
}
