package com.coding.vowels.impl;

import com.coding.vowels.FilesReaderWriter;
import com.coding.vowels.ProcessingVowels;
import com.coding.vowels.WordProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;

/*
This Class will combine all processes required for the task. Reading from file , Processing it an dwriting back
 */

@Component
@Service
@Slf4j
public class ProcessingVowelsImpl implements ProcessingVowels {

    @Value("${inputFile}")
    private String inputFile;
    @Value("${outputFile}")
    private String outPutFile;
    @Autowired
    private final FilesReaderWriter filesReaderWriter;
    @Autowired
    private final WordProcessor wordProcessor;

    public ProcessingVowelsImpl(FilesReaderWriter filesReaderWriter, WordProcessor wordProcessor) {
        this.filesReaderWriter = filesReaderWriter;
        this.wordProcessor = wordProcessor;
    }
    @Override
    public void process() throws FileNotFoundException {
        log.info("Processing input from file  " + inputFile);
        String inputContent = filesReaderWriter.readFromFile(inputFile);
        String processedContent = wordProcessor.processWord(inputContent.toLowerCase());
        filesReaderWriter.writeToFile(outPutFile, processedContent);
        log.info("Input processed successfully and Output is written to file " + outPutFile);
    }
}
