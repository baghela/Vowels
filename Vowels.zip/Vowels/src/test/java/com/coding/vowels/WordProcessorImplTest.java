package com.coding.vowels;

import com.coding.vowels.impl.WordProcessorImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class WordProcessorImplTest {
    @Autowired
    WordProcessorImpl wordProcessorImpl;

    @Test
    void processWordTest()
    {
        String testString="Platon made bamboo boats.";
        Assertions.assertEquals("(({a,o}) ,6) -> 3.0\n" +
                "(({a,e}) ,4) -> 2.0\n" +
                "(({a,o}) ,6) -> 2.0\n" +
                "(({o,a}) ,5) -> 2.5\n",wordProcessorImpl.processWord(testString));

    }
    @Test
    void getVowelsTest()
    {
        String word="amit";
        String wordWithoutVowels="lmnh";

        Assertions.assertEquals("a,i",wordProcessorImpl.getVowels(word));
        Assertions.assertEquals(null,wordProcessorImpl.getVowels(wordWithoutVowels));

    }

}
