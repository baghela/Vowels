package com.coding.vowels;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.FileNotFoundException;
import java.io.IOException;

@SpringBootTest
public class FilesReaderWriterImplTest {

    @Autowired
    FilesReaderWriter filesReaderWriter;
    @Test
    void testFileExists()
    {
        String inputFile="YOUR_DRIVE\\Input.txt";
        String outputFile="YOUR_DRIVE\\Output.txt";
        Assertions.assertDoesNotThrow(() -> filesReaderWriter.readFromFile(inputFile));
        Assertions.assertDoesNotThrow(() -> filesReaderWriter.writeToFile(outputFile,"Test Content"));
    }
    @Test
    void testFileNotExists()
    {
        String inputFile="D:\\Users\\ambaghel\\Desktop\\Input.txt";
        String outputFile="D:\\Users\\ambaghel\\Desktop\\Output.txt";
        Assertions.assertThrows(FileNotFoundException.class,() -> filesReaderWriter.readFromFile(inputFile));
        Assertions.assertThrows(FileNotFoundException.class,() -> filesReaderWriter.writeToFile(outputFile,"Test content"));
    }
}
