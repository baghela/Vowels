package com.coding.vowels;

import com.coding.vowels.impl.ProcessingVowelsImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProcessingVowelsImplTest {

    @Autowired
    ProcessingVowelsImpl processingVowelsImpl;
    @Test
    void testProcess()
    {
        Assertions.assertDoesNotThrow(() -> processingVowelsImpl.process());
    }

}
